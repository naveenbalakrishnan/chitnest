<?php

namespace Drupal\loan_emi_details\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Render\Markup;

class LoanEmiController extends ControllerBase {

  public function emiReport() {
    $header = [
      $this->t('EMI No'),
      $this->t('Customer Name'),
      $this->t('Start Date'),
      $this->t('End Date'),
      $this->t('Status'),
      $this->t('Penalty'),
      $this->t('Agent'),
      $this->t('Collected Date'),
      $this->t('Collected Mode'),
    ];

    $query = Database::getConnection()->select('loan_emi_details', 'l')
      ->fields('l')
      ->orderBy('emi_number', 'ASC');
    $results = $query->execute();

    $rows = [];


	
	foreach ($results as $row) {
  $now = new \DateTime();
  $end_date = new \DateTime($row->end_date);
  $collected = !empty($row->collected_date);

  // Determine status label
  if ($collected) {
    $status_text = 'Paid';
    $status_color = '#5cb85c'; // Green
  } elseif ($end_date < $now) {
    $status_text = 'Pending';
    $status_color = '#d9534f'; // Red
  } else {
    $status_text = 'Upcoming';
    $status_color = '#f0ad4e'; // Orange
  }

  $status_label = "<span style=\"color: $status_color; font-weight: bold;\">$status_text</span>";

  $rows[] = [
    $row->emi_number,
    $row->customer_name,
    date('d M Y', strtotime($row->start_date)),
    date('d M Y', strtotime($row->end_date)),
    Markup::create($status_label),
    $row->penalty ?: '0',
    $row->agent_collected,
    $row->collected_date ? date('d M Y', strtotime($row->collected_date)) : '-',
    $row->collected_mode ?: '-',
  ];
}



    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#attributes' => ['class' => ['emi-report-table', 'table', 'table-striped', 'table-bordered']],
      '#empty' => $this->t('No EMI records found.'),
      '#attached' => [
        'library' => [
          'loan_emi_details/emi_report_styles',
        ],
      ],
    ];
  }
}

<?php

namespace Drupal\loan_emi_details\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Render\Markup;

class LoanEmiEditableReportForm extends FormBase {

  public function getFormId() {
    return 'loan_emi_editable_report_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $header = [
      $this->t('EMI No'),
      $this->t('Customer Name'),
      $this->t('Start Date'),
      $this->t('End Date'),
      $this->t('Status'),
      $this->t('Penalty'),
      $this->t('Agent'),
      $this->t('Collected Date'),
      $this->t('Collected Mode'),
    ];

    $form['emi_table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#empty' => $this->t('No EMI records found.'),
      '#attributes' => ['class' => ['table', 'table-bordered']],
    ];

    $query = Database::getConnection()->select('loan_emi_details', 'l')
      ->fields('l')
      ->orderBy('emi_number', 'ASC');

    $results = $query->execute()->fetchAll();

    foreach ($results as $row) {
      $key = $row->emi_id ?? $row->emi_number ?? uniqid();

      $now = new \DateTime();
      $end_date = new \DateTime($row->end_date);
      $collected = !empty($row->collected_date);

      if ($collected) {
        $status_text = 'Paid';
        $status_color = '#5cb85c';
      } elseif ($end_date < $now) {
        $status_text = 'Pending';
        $status_color = '#d9534f';
      } else {
        $status_text = 'Upcoming';
        $status_color = '#f0ad4e';
      }

      $status_label = Markup::create("<span style=\"color: $status_color; font-weight: bold;\">$status_text</span>");

      $form['emi_table'][$key]['emi_number'] = ['#markup' => $row->emi_number];
      $form['emi_table'][$key]['customer_name'] = ['#markup' => $row->customer_name];
      $form['emi_table'][$key]['start_date'] = ['#markup' => date('d M Y', strtotime($row->start_date))];
      $form['emi_table'][$key]['end_date'] = ['#markup' => date('d M Y', strtotime($row->end_date))];
      $form['emi_table'][$key]['status'] = ['#markup' => $status_label];

      // Editable penalty field
      $form['emi_table'][$key]['penalty'] = [
        '#type' => 'textfield',
        '#default_value' => $row->penalty ?? '0',
        '#size' => 5,
      ];

      $form['emi_table'][$key]['agent_collected'] = ['#markup' => $row->agent_collected];

      $form['emi_table'][$key]['collected_date'] = [
        '#type' => 'date',
        '#default_value' => $row->collected_date ? date('Y-m-d', strtotime($row->collected_date)) : '',
      ];

      $form['emi_table'][$key]['collected_mode'] = [
        '#type' => 'textfield',
        '#default_value' => $row->collected_mode ?? '',
        '#size' => 10,
      ];
    }

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save Changes'),
      '#attributes' => ['class' => ['button', 'button--primary']],
    ];

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValue('emi_table');
    $connection = Database::getConnection();

    foreach ($values as $emi_id => $data) {
      if (!is_numeric($emi_id)) {
        continue;
      }

      $connection->update('loan_emi_details')
        ->fields([
          'collected_date' => $data['collected_date'] ?: NULL,
          'collected_mode' => $data['collected_mode'] ?: '',
          'penalty' => $data['penalty'] ?? '0',
        ])
        ->condition('emi_number', $emi_id)
        ->execute();
    }

    $this->messenger()->addStatus($this->t('Loan EMI updates have been saved successfully.'));
  }
}
